<template>
  <div class="container">
    <div class="bg"></div>
    <div class="form">
      <h2>{{!isSignUp?'用户登录':'注册账号'}}</h2>
      <transition name="fade">
      <div class="row" v-if="!isSignUp">
        <div class="form-horizontal col-md-8 col-md-offset-2 col-xs-8 col-xs-offset-2">
            <div class="form-group ">
              <div class="input-group ipt">
                <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                <input class="form-control required" type="text" placeholder="用户名" id="username" name="username"
                       autofocus="autofocus" maxlength="20" v-model="username"/>
              </div>
            </div>
            <div class="form-group ">
              <div class="input-group ipt">
                <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                <input class="form-control required" type="password" placeholder="密码" id="password" name="password"
                       maxlength="20" v-model="password"/>
              </div>
            </div>
            <div class="form-group col-md-offset-6">
              <button type="primary" class="btn btn-success dl"  @click="Login">登录</button>
            </div>
          <span class="col-md-5 sp1 sbtn" @click="signUp">注册账号</span>
          <span class="col-md-2 sp1">|</span>
          <span class="col-md-5 sp1 sbtn">忘记密码</span>
        </div>
      </div>
      </transition>
      <transition name="fade">
      <div v-if="isSignUp" class="row">
        <div class="form-horizontal col-md-8 col-md-offset-2 col-xs-8 col-xs-offset-2">
          <div class="form-group">
            <label for="username1" class="lbl1">用户名</label>
            <input class="form-control required" type="text" placeholder="1~20位" id="username1" name="username1"
                   autofocus="autofocus" maxlength="20" v-model="username1">
          </div>
          <div class="form-group">
            <label for="password1" class="lbl1">密码</label>
            <input class="form-control required" type="password" placeholder="6~20位" id="password1" name="password1"
                    maxlength="20" v-model="password1">
          </div>
          <div class="form-group">
            <label for="email" class="lbl1">邮箱</label>
            <input class="form-control required" type="email" placeholder="请选择常用邮箱" id="email" name="email" v-model="email">
          </div>
          <div class="form-group">
            <label for="collage" class="lbl1">学校</label>
            <input class="form-control required" type="text" placeholder="" id="collage" name="collage" v-model="collage">
          </div>
          <div class="form-group">
            <label for="dept" class="lbl1">院系</label>
            <input class="form-control required" type="text" placeholder="" id="dept" name="dept" v-model="dept">
          </div>
          <div class="form-group">
            <label for="major" class="lbl1">专业</label>
            <input class="form-control required" type="text" placeholder="" id="major" name="major" v-model="major">
          </div>
          <div class="form-group">
            <label for="year" class="lbl1">年级</label>
            <input class="form-control required" type="text" placeholder="" id="year" name="year" v-model="year">
          </div>
          <div class="form-group col-md-offset-6">
            <button type="primary" class="btn btn-success zc" @click="register">注册</button>
          </div>
          <span class=" sp1 sbtn" @click="signUp">返回登录</span>
        </div>
      </div>
      </transition>
    </div>
  </div>
</template>

<script>

export default {
  name: 'login',
  data: function () {
    return {
      isSignUp: false,
      username: '',
      password: '',
      username1: '',
      password1: '',
      email: '',
      collage: '',
      dept: '',
      major: '',
      year: ''
    }
  },
  methods: {
    signUp: function (e) {
      this.isSignUp = !this.isSignUp
    },
    Login: function (e) {
      this.$request('post', '/api/login', {
        username: this.username,
        password: this.password
      }).then((res) => {
        // alert(res.data)
        if (res.status === 200) {
          // console.log(res.data)
          if (res.data.Status === 200) {
            // alert('登录成功')
            this.$cookies.set('user', encodeURIComponent(JSON.stringify(res.data.Data)), 60 * 60 * 12)
            console.log(res.data.Data)
            this.$store.commit('setUser', res.data.Data)
            this.$router.push(this.$route.query.redirect)
          } else {
            alert('用户名或密码错误')
          }
        } else {
          alert('登录失败')
        }
      }).catch((res) => {
        alert('登录失败')
      })
    },
    register: function (e) {
      const data = {
        username: this.username1,
        password: this.password1,
        email: this.email,
        school: this.collage,
        academy: this.dept,
        major: this.major,
        grade: this.year
      }
      console.log(data)
      this.$request('post', 'api/create', data).then((res) => {
        // alert('ok')
        console.log(res)
        if (res.status === 200) {
          if (res.data.Status === 200) {
            alert('注册成功')
            this.isSignUp = false
          } else if (res.data.Status === 603) {
            alert('用户名已存在')
          } else if (res.data.Status === 801) {
            alert('用户信息不完整')
          }
        }
      }).catch((res) => {
        alert('注册失败')
      })
    }
  }
}
</script>

<style scoped>
  .main {
    width: 200px;
    height: 300px;
    background: white;
  }

  .bg {
    background: url("../assets/bg0.jpg") no-repeat;
    background-size: cover;
    width: 100%;
    height: 100%;
    position: fixed;
    z-index: -1;
    left: 0;
  }

  .ipt {
    margin-top: 30px;
  }

  .form {
    width: 400px;
    max-height: 500px;
    background: rgba(255, 255, 255, 1);
    margin: 150px auto 0 auto;
    padding: 20px 0 50px 0;
    -moz-box-shadow: 2px 2px 5px #333333;
    -webkit-box-shadow: 2px 2px 5px #333333;
    box-shadow: 2px 2px 5px #333333;
    border-radius: 5px;
    overflow-x: hidden;
    overflow-y: auto;
  }

  .dl {
    width: 100px;
    margin-bottom: 20px;
  }

  .sp1 {
    color: #337ab7;
  }

  .sbtn {
    cursor: pointer;
  }

  .lbl1{
    float: left;
    margin: 15px 0 15px 5px;
  }

  .zc{
    width: 100px;
    margin-bottom: 5px;
    margin-top: 20px;
  }

  .form::-webkit-scrollbar{
    width: 12px;
  }

  .form::-webkit-scrollbar-track {
    background-color: transparent;
  }

  .form::-webkit-scrollbar-thumb{
    border-radius: 20px;
    background-color: #E8E8E8;
  }

  .fade-enter-active {
    transition: opacity .5s;
  }

  .fade-leave-active{
    transition: 0s;
  }
  .fade-enter, .fade-leave-to /* .fade-leave-active below version 2.1.8 */ {
    opacity: 0;
  }

</style>
