<template>
  <div class="container">
    <div class="page-header">
    <h1>- 公共区 -</h1>
    </div>
    <div class="row al text-left">
    <div class="col-md-6">
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h3 class="panel-title">近期通知</h3>
        </div>
        <div class="panel-body">
          <div class="list-group">
            <router-link v-for="(notice,index) in notices.slice(0,5)" :key="index" :to="{name:'noticeDetail',query:{id:index}}">
            <a  href="#" class="list-group-item itm">
              <h4 class="list-group-item-heading ittl">{{notice.Title}}<small class="pull-right">{{notice.UploadTime}}</small></h4>
              <p class="list-group-item-text">{{notice.Content}}</p>
            </a>
            </router-link>
          </div>
        </div>
      </div>
    </div>
      <div class="col-md-6">
        <div class="panel panel-primary">
          <div class="panel-heading">
            <h3 class="panel-title">公共课资料</h3>
          </div>
          <div class="panel-body">
            <div class="list-group">
              <router-link v-for="(fileItem,index) in fileItems.slice(0,5)" :key="index" :to="{name:'fileDetail',query:{id:index}}">
              <a href="#" class="list-group-item itm">
                <h4 class="list-group-item-heading ittl">{{fileItem.Filename.split('-').pop()}}<small class="pull-right">{{fileItem.UploadTime}}</small></h4>
                <p class="list-group-item-text">{{fileItem.Description}}</p>
              </a>
              </router-link>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapState } from 'vuex'
export default {
  name: 'common',
  data: function () {
    return {
      notices: [],
      fileItems: []
    }
  },
  methods: {
    getNoticesAndFiles: function () {
      this.$request('get', '/api/notification', {
        token: this.$store.state.token,
        school: this.schoolNo === -1 ? this.school : this.schoolNo
      }).then((res) => {
        if (res.status === 200 && res.data.Status === 200) {
          this.notices = res.data.Data
          this.$store.commit('setNotices', {data: res.data.Data})
        }
      })
      this.$request('post', '/api/exact-file-list', {
        token: this.$store.state.token,
        school: this.schoolNo === -1 ? this.school : this.schoolNo,
        academy: 'general',
        major: 'general'
      }).then((res) => {
        if (res.status === 200 && res.data.Status === 200) {
          this.fileItems = res.data.Data
          this.$store.commit('setFiles', {data: res.data.Data})
        }
      })
    }
  },
  computed: mapState({
    schoolNo: 'schoolNo',
    school: 'school'
  }),
  watch: {
    schoolNo: function () {
      this.getNoticesAndFiles()
    }
  },
  mounted () {
    this.$store.commit('setAreaNo', 0)
    this.getNoticesAndFiles()
  }
}
</script>

<style scoped>
  .al{
    width: 100%;
  }

  .itm p{
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
    position:relative;
    line-height:1.3em;
    max-height:3.9em;/* 3 倍line-height  多少倍就是多少行*/
  }

  .ittl{
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
</style>
