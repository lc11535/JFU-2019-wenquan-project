<template>
  <div class="container">
    <div class="page-header">
      <h1 class="text-left">- 专业区 -</h1>
    </div>
    <div class="row text-left">
      <div class="col-md-12">
        <div class="panel panel-primary bd">
          <div class="panel-body">
            <div class="list-group">
              <router-link v-for="(file,index) in files.slice(0,12)" :key="index" :to="{name:'fileDetail',query:{id:index}}">
              <a class="col-md-4 col-sm-6 list-group-item itm">
                <h4 class="list-group-item-heading ittl">
                  <small class="">{{file.Course}}</small>&nbsp;&nbsp;&nbsp;<span>{{file.Filename.split('-').pop()}}</span></h4>
                <p class="list-group-item-text">{{file.Description}}</p>
                <div class="text-right">
                  <!--span class="tags">文件类型：{{file.type}}</span-->
                  <span class="tags">上传者：{{file.Uploader}}</span>
                  <!--span class="tags">下载次数：{{file.count}}</span><br-->
                  <span class="tags">上传日期:{{file.UploadTime}}</span>
                </div>
              </a></router-link>
            </div>
          </div>
          <nav aria-label="Page navigation" class="text-center">
            <ul class="pagination">
              <li>
                <a class="pg" aria-label="Previous" @click="prevPage">
                  <span aria-hidden="true">&laquo;</span>
                </a>
              </li>
              <li v-for="(item,index) in pageLi" v-bind:key="index" :class="{active: item===page}">
                <a v-if="item!==-1" @click="toPage(item)" class="pg">{{item}}</a>
                <span v-else>...</span>
              </li>
              <li>
                <a class="pg" aria-label="Next" @click="nextPage">
                  <span aria-hidden="true">&raquo;</span>
                </a>
              </li>
            </ul>
          </nav>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapState } from 'vuex'
export default {
  name: 'major',
  data: function () {
    return {
      files: [],
      pages: 1,
      page: 1
    }
  },
  computed: {
    pageLi: function () {
      const n = this.pages
      if (n <= 7) {
        let a = new Array(n)
        for (let i = 1; i <= n; i++) {
          a[i - 1] = i
        }
        return a
      } else {
        const now = this.page
        let a = new Array(7)
        if (now + 2 < n) {
          const st = Math.max(now - 2, 1)
          for (let i = 0; i < 5; i++) {
            a[i] = st + i
          }
          a[5] = -1
          a[6] = n
          return a
        } else {
          a[0] = 1
          a[1] = -1
          const ed = Math.min(now + 2, n)
          for (let i = 0; i < 5; i++) {
            a[i + 2] = ed - (4 - i)
          }
          return a
        }
      }
    },
    ...mapState({
      school: 'school',
      academyNo: 'academyNo',
      majorNo: 'majorNo',
      schoolNo: 'schoolNo',
      academyMajor: 'acaMaj'
    })
  },
  watch: {
    schoolNo: function () {
      this.clear()
    },
    academyNo: function () {
      this.pageRequest(1)
    },
    majorNo: function () {
      this.pageRequest(1)
    }
  },
  methods: {
    pageRequest: function (page) {
      if (this.academyNo !== -1) {
        this.$request('post', 'api/exact-file-list', {
          token: this.$store.state.token,
          username: this.$store.state.username,
          page: page,
          school: this.school,
          academy: this.academyNo,
          major: this.academyMajor[this.academyNo][this.majorNo]
        }).then((res) => {
          if (res.status === 200) {
            if (res.data.Status === 200) {
              // console.log(res.data)
              this.files = res.data.Data
              // this.pages = res.data.page_num
              // this.page = res.data.page
              this.pages = 1
              this.page = 1
              this.$store.commit('setFiles', {data: res.data.Data})
            }
          }
        })
      }
    },
    clear: function () {
      this.page = 1
      this.pages = 1
      this.files = []
    },
    toPage: function (page) {
      if (this.page !== page) {
        this.pageRequest(page)
      }
    },
    prevPage: function () {
      if (this.page > 1) {
        this.pageRequest(this.page - 1)
      }
    },
    nextPage: function () {
      if (this.page < this.pages) {
        this.pageRequest(this.page + 1)
      }
    }
  },
  mounted () {
    this.$store.commit('setAreaNo', 1)
    this.pageRequest(1)
  }
}
</script>

<style scoped>
  .itm p {
    margin-left: 20px;
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
    position: relative;
    line-height: 1.3em;
    height: 2.6em; /* 3 倍line-height  多少倍就是多少行*/
  }

  .itm {
    margin-bottom: 10px;
    border-radius: 5px;
  }

  .tags {
    font-size: 12px;
    margin-right: 5px;
  }

  .bd {

  }

  .pg{
    cursor: pointer;
  }
  .ittl{
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
</style>
