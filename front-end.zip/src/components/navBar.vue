<template>
  <div >
    <div class="hd text-left">
      <h1 style="padding:30px; margin-top: 0;">JFU校园学习资料分享平台</h1>
    </div>
    <nav class="navbar navbar-default">
      <div class="container-fluid">
        <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" aria-expanded="false">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <span class="navbar-brand">欢迎，{{username}}</span>
        <!--a class="navbar-brand" href="#">Brand</a-->
        </div>
        <div class="collapse navbar-collapse" id="navbar-collapse">
          <ul class="nav navbar-nav">
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                <span v-if="schoolNo===-1">{{school}}</span><span v-else>{{schoolNo}}</span> <span class="caret"></span>
              </a>
              <ul class="dropdown-menu">
                <li><a>{{school}} (当前学校)</a></li>
                <li role="separator" class="divider"></li>
                <li v-for="(school, index) in schools" :key="index">
                  <a @click="changeSchool(school)">{{school}}</a>
                </li>
              </ul>
            </li>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                {{areas[areaNo].name}}<span class="caret"></span>
              </a>
              <ul class="dropdown-menu">
                <li v-for="(area, index) in areas" :key="index">
                  <a @click="changeArea(index,area.url)">{{area.name}}</a>
                </li>
              </ul>
            </li>
            <li v-if="areaNo===0" class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                {{commons[commonNo].name}}<span class="caret"></span>
              </a>
              <ul class="dropdown-menu">
                <li v-for="(common, index) in commons" :key="index">
                  <a  @click="changeCommon(index)">{{common.name}}</a>
                </li>
              </ul>
            </li>
            <li v-if="areaNo===1" class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                {{academyNo===-1?'请选择院系':academyNo}}<span class="caret"></span>
              </a>
              <ul class="dropdown-menu">
                <li v-for="(academy, index) in academyMajor" :key="index">
                  <a @click="changeAcademy(index)">{{index}}</a>
                </li>
              </ul>
            </li>
            <li v-if="areaNo===1" class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                {{academyNo===-1?'请选择专业':academyMajor[academyNo][majorNo]}}<span class="caret"></span>
              </a>
              <ul class="dropdown-menu">
                <li v-for="(major, index) in academyMajor[academyNo]" :key="index">
                  <a @click="changeMajor(index)">{{major}}</a>
                </li>
              </ul>
            </li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
            <li><a data-toggle="modal" data-target="#myModal">上传文件</a></li>
            <li><a @click="logout()">退出登录</a></li>
          </ul>
        </div>
      </div>
    </nav>
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="myModalLabel">上传文件</h4>
          </div>
          <div class="modal-body">
            <div class="row">
              <div class="form-horizontal col-md-12  ">
                <div class="form-group">
                  <label for="filename" class="col-sm-2 control-label">文件名</label>
                  <div class="col-sm-10">
                  <input class="form-control required" type="text" id="filename" name="filename"
                         autofocus="autofocus" maxlength="20" v-model="filename">
                  </div>
                </div>
                <div class="form-group">
                  <label for="filename" class="col-sm-2 control-label">文件描述</label>
                  <div class="col-sm-10">
                    <textarea class="form-control" rows="3" id="disc" name="disc"
                              v-model="filedesc"></textarea>
                  </div>
                </div>
                <div class="form-group">
                  <label for="upSchool" class="col-sm-2 control-label">上传至</label>
                  <div class="col-sm-4">
                    <select class="form-control" id="upSchool" name="upSchool" >
                      <option v-for="(item,index) in schools" :key="index" :value="item" :selected="(item===schoolNo||item===school)?'select':''">{{item}}</option>
                    </select>
                  </div>
                  <div class="col-sm-3">
                    <select class="form-control" id="upAcademy" name="upAcademy">
                      <option v-for="(item,index) in academyMajor" :key="index" :value="index" :selected="(index===academyNo)?'select':''">{{index}}</option>
                    </select>
                  </div>
                  <div class="col-sm-3">
                    <select class="form-control" id="upMajor" name="upMajor">
                      <option v-for="(item,index) in academyMajor[academyNo===-1?0:academyNo]" :key="index" :value="item" :selected="(index===majorNo)?'select':''">{{item}}</option>
                    </select>
                  </div>
                </div>
                <div class="form-group">
                  <label for="upCourse" class="col-sm-2 control-label">所属课程</label>
                  <div class="col-sm-10">
                    <input class="form-control required" type="text" id="upCourse" name="upCourse"
                           maxlength="20" v-model="upCourse">
                  </div>
                </div>
                <div class="form-group">
                  <label for="auth" class="col-sm-2 control-label">权限</label>
                  <div class="col-sm-5">
                    <select class="form-control" id="auth" name="auth">
                      <option value="0">所有人可下载(公共区)</option>
                      <option value="1">仅本校学生可下载</option>
                      <option value="2">私密</option>
                    </select>
                  </div>
                </div>
                <div class="form-group">
                  <label for="auth" class="col-sm-2 control-label">选择文件</label>
                  <div class="col-sm-10">
                    <input type="file" class="form-control file" id="upFile">
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">取消</button>
            <button type="button" class="btn btn-primary" @click="upload()">上传</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapState } from 'vuex'
import axios from 'axios'
export default {
  name: 'navBar',
  data: function () {
    return {
      areas: [
        {
          name: '公共区',
          url: '/common'
        },
        {
          name: '专业区',
          url: '/major'
        }
      ],
      commons: [
        {
          name: '全部'
        },
        {
          name: '近期通知',
          url: ''
        },
        {
          name: '公共课资料',
          url: ''
        }
      ],
      filename: '',
      filedesc: '',
      upCourse: ''
    }
  },
  methods: {
    changeSchool: function (id) {
      this.$store.commit('setSchoolNo', id)
    },
    changeArea: function (index, url) {
      this.$store.commit('setAreaNo', index)
      // console.log(this.academyMajor)
      if (index === 1 && !this.academyMajor) {
        this.getAcaMaj()
      }
      this.$router.push(url)
    },
    changeCommon: function (index) {
      this.$store.commit('setCommonNo', index)
    },
    changeAcademy: function (index) {
      this.$store.commit('setAcademyNo', index)
      this.changeMajor(0)
    },
    changeMajor: function (index) {
      this.$store.commit('setMajorNo', index)
    },
    getAcaMaj: function () {
      let school = this.schoolNo
      if (school === -1) {
        school = this.school
      }
      this.$request('get', 'api/academy-major', {
        school: school
      }).then((res) => {
        if (res.status === 200 && res.data.Status === 200) {
          let academyMajor = res.data.Data
          // console.log(this.academyMajor)
          for (let i in academyMajor) {
            academyMajor[i].splice(0, 0, '全部专业')
          }
          this.$store.commit('setAcaMaj', academyMajor)
          this.changeMajor(0)
          this.changeAcademy(-1)
          // console.log(this.academyMajor)
        }
      }).catch()
    },
    logout: function () {
      this.$cookies.remove('user')
      window.sessionStorage.clear()
      this.$store.commit('clearAll')
      this.$router.go(0)
    },
    upload: function () {
      // window.$('#myModal').modal('hide')
      console.log(document.getElementById('upFile').files[0])
      let formData = new FormData()
      formData.append('uploaded-file', document.getElementById('upFile').files[0])
      formData.append('course', this.upCourse)
      formData.append('uploader', this.username)
      formData.append('upload-time', this.$formatDate(new Date(), 'yyyy-MM-dd'))
      formData.append('description', this.filedesc)
      formData.append('school', document.getElementById('upSchool').value)
      formData.append('academy', document.getElementById('upAcademy').value)
      formData.append('major', document.getElementById('upMajor').value)
      formData.append('auth', document.getElementById('auth').value)
      formData.append('filename', this.filename)
      // let data = {
      //   filename: this.filename,
      //   course: this.course,
      //   uploader: this.username,
      //   'upload-time': this.$formatDate(new Date(), 'yyyy-mm-dd'),
      //   description: this.filedesc,
      //   school: document.getElementById('upSchool').value,
      //   academy: document.getElementById('upAcademy').value,
      //   major: document.getElementById('upMajor').value,
      //   auth: document.getElementById('auth').value,
      //   'uploaded-file': document.getElementById('upFile').files[0]
      // }
      // this.$request('post', '/api/upload', formData, 'multipart/form-data').then((res) => {
      //   console.log(res)
      //   window.$('#myModal').modal('hide')
      // })
      axios({
        method: 'post',
        url: '/api/upload',
        data: formData,
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      }).then((res) => {
        console.log(res)
        window.$('#myModal').modal('hide')
      })
    }
  },
  computed:
    mapState({
      school: 'school',
      schoolNo: 'schoolNo',
      areaNo: 'areaNo',
      commonNo: 'commonNo',
      academyNo: 'academyNo',
      majorNo: 'majorNo',
      username: 'username',
      academyMajor: 'acaMaj',
      schools: 'schools'
    }),
  watch: {
    schoolNo: function () {
      if (this.areaNo === 1) {
        this.getAcaMaj()
      }
    }
  },
  mounted () {
    // alert(new Date().toDateString())
    const data = JSON.parse(decodeURIComponent(this.$cookies.get('user')))
    console.log(data)
    this.$store.commit('setUser', data)
    // console.log(this.academyNo)
    if (this.schools.length <= 0) {
      this.$request('get', 'api/school-list', {}).then((res) => {
        if (res.status === 200 && res.data.Status === 200) {
          this.schools = res.data.Data
          this.$store.commit('setSchools', {data: res.data.Data})
        }
        // console.log(this.schools)
      })
      console.log(this.academyMajor)
      if (!this.academyMajor.length || this.academyMajor.length <= 0) {
        this.getAcaMaj()
      }
    }
  }
}
</script>

<style scoped>

  .hd{
    width: 100%;
    height: 100px;
    background: #153172;
    color: white;
    padding: 0;
    margin: 0;
  }

  .dropdown-menu a, .navbar-right a{
    cursor: pointer;
  }
  .lbl1{
    float: left;
    margin: 15px 0 15px 5px;
  }
</style>
