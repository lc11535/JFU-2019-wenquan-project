<template>
  <div class="container">
    <div class="page-header">
      <h1>- 文件详情 -</h1>
      <a style="position: relative;left:40%;cursor: pointer" @click="$router.go(-1)">返回列表</a>
    </div>
    <div class="row">
      <div class="col-md-6 ">
        <div class="panel panel-primary pnl">
          <h3>{{fname}}</h3>
          <ul class="text-left list-group">
            <li class="list-group-item">文件类型：{{ftype}}</li>
            <li class="list-group-item">文件科目：{{file.Course}}</li>
            <li class="list-group-item">所属专业：{{file.School}}-{{file.Academy}}-{{file.Major}}</li>
            <li class="list-group-item">文件描述：{{file.Description}}</li>
            <li class="list-group-item">文件大小：{{(file.Size/1024/1024).toFixed(2)}}MB</li>
            <li class="list-group-item">上传者：{{file.Uploader}}</li>
            <li class="list-group-item">上传日期：{{file.UploadTime}}</li>
            <li class="list-group-item">下载次数：{{file.DownloadTime}}</li>
          </ul>
          <a target="_blank" :href="'api/download?filename='+file.Filename"><button type="button" class="btn btn-success btn-dl">下载文件</button></a>
        </div>
      </div>
      <div class="col-md-6 ">
        <div class="panel panel-primary pnl">
          <h3>评论({{comments.length}})</h3>
          <textarea class="form-control" rows="3" placeholder="请输入您的评论" v-model="commentContent"></textarea>
          <button type="button" class=" btn btn-success btn-dl btn-sub" @click="postComment()">发表</button>
          <ul class="list-group" >
            <li v-for="(item,index) in comments" :key="index" class="list-group-item">
              <div class="text-left"><span class="name">{{item.Commentator}} :</span></div><p>{{item.Content}}</p>
              <div class="text-right"><small class="time">{{item.CommentTime}}</small></div></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapState } from 'vuex'
export default {
  name: 'fileDetail',
  data: function () {
    return {
      type: 'pdf',
      datas: {},
      id: '',
      comments: [],
      commentContent: ''
    }
  },
  methods: {
    getComment: function () {
      this.$request('get', 'api/comment-set', {
        filename: this.file.Filename
      }).then((res) => {
        if (res.status === 200 && res.data.Status === 200) {
          this.comments = res.data.Data
        }
      }).catch()
    },
    postComment: function () {
      this.$request('post', 'api/post-comment', {
        filename: this.file.Filename,
        content: this.commentContent,
        poster: this.$store.state.username,
        'post-time': this.$formatDate(new Date(), 'yyyy-MM-dd')
      }).then((res) => {
        this.commentContent = ''
        this.getComment()
      })
    }
  },
  mounted () {
    // alert(this.$route.query.id)
    // console.log(this.$route.params)
    this.id = this.$route.query.id
    // console.log(this.files)
    this.getComment()
  },
  computed: {
    fname: function () {
      return this.file.Filename.split('-').pop().split('.')[0]
    },
    ftype: function () {
      return this.file.Filename.split('-').pop().split('.')[1]
    },
    ...mapState({
      file: function
      (state) {
        // alert(this.$route.query.id)
        // console.log(state.files)
        return state.files[this.$route.query.id]
      }
    })
  }
}
</script>

<style scoped>
.pnl{
  padding: 10px;
}
  .btn-dl{
    margin-top: 20px;
    margin-bottom: 20px;
  }

  .time{
    color: #99a2aa;
  }
  .name{
    color: #337ab7;
  }
  .btn-sub{
    position: relative;
    left: 40%;
  }
</style>
