import Vue from 'vue'
import Vuex from 'vuex'
Vue.use(Vuex)
const store = new Vuex.Store({
  state: {
    username: '',
    token: '',
    school: '',
    academy: '',
    major: '',
    grade: '',
    auth: '',
    schoolNo: window.sessionStorage.getItem('schoolNo') || -1,
    areaNo: parseInt(window.sessionStorage.getItem('areaNo')) || 0,
    commonNo: window.sessionStorage.getItem('commonNo') || 0,
    academyNo: window.sessionStorage.getItem('academyNo') || -1,
    majorNo: window.sessionStorage.getItem('majorNo') || 0,
    acaMaj: JSON.parse(window.sessionStorage.getItem('acaMaj')) || {},
    files: JSON.parse(window.sessionStorage.getItem('files')) || {},
    notices: JSON.parse(window.sessionStorage.getItem('notices')) || {},
    schools: window.sessionStorage.getItem('schools') ? window.sessionStorage.getItem('schools').split(',') : []
  },
  mutations: {
    setUser (state, pl) {
      state.username = pl.Alias
      state.school = pl.School
      state.academy = pl.Academy
      state.major = pl.Major
      state.grade = pl.Grade
      state.auth = pl.Auth
      state.token = pl.SessionID
    },
    setSchoolNo (state, no) {
      state.schoolNo = no
      window.sessionStorage.setItem('schoolNo', no)
    },
    setAreaNo (state, no) {
      state.areaNo = no
      window.sessionStorage.setItem('areaNo', no)
    },
    setCommonNo (state, no) {
      state.commonNo = no
      window.sessionStorage.setItem('commonNo', no)
    },
    setAcademyNo (state, no) {
      // alert(1234)
      state.academyNo = no
      window.sessionStorage.setItem('academyNo', no)
      if (no === -1) {
        window.sessionStorage.removeItem('academyNo')
      }
    },
    setMajorNo (state, no) {
      // alert(123)
      state.majorNo = no
      window.sessionStorage.setItem('majorNo', no)
    },
    setAcaMaj (state, data) {
      // alert(1234)
      state.acaMaj = data
      data = JSON.stringify(data)
      window.sessionStorage.setItem('acaMaj', data)
    },
    setFiles (state, pl) {
      state.files = pl.data
      window.sessionStorage.setItem('files', JSON.stringify(pl.data))
    },
    setSchools (state, pl) {
      state.schools = pl.data
      window.sessionStorage.setItem('schools', pl.data.toString())
    },
    setNotices (state, pl)  {
      state.notices = pl.data
      window.sessionStorage.setItem('notices', JSON.stringify(pl.data))
    },
    clearAll (state) {
      state.username = ''
    }
  },
  actions: {

  }
})

export default store
