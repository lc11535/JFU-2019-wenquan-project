<template>
  <div class="container">
    <div class="page-header">
      <h1>- 通知详情 -</h1>
      <a style="position: relative;left:40%;cursor: pointer" @click="$router.go(-1)">返回列表</a>
    </div>
    <div class="row">
      <div class="col-md-12 ">
        <div class="panel panel-primary pnl">
          <h3>{{notice.Title}}</h3>
          <ul class=" list-group">
            <li class="list-group-item">上传日期：{{notice.UploadTime}}</li>
            <li class="list-group-item">{{notice.Content}}</li>
          </ul>
        </div>
      </div>

    </div>
  </div>
</template>

<script>
  import { mapState } from 'vuex'
  export default {
    name: 'fileDetail',
    data: function () {
      return {
        datas: {},
        id: '',
        comments: [],
        commentContent: ''
      }
    },
    methods: {
    },
    mounted () {
      // alert(this.$route.query.id)
      // console.log(this.$route.params)
      this.id = this.$route.query.id
      // console.log(this.files)
    },
    computed: {
      ...mapState({
        notice: function
          (state) {
          // alert(this.$route.query.id)
          // console.log(state.files)
          return state.notices[this.$route.query.id]
        }
      })
    }
  }
</script>

<style scoped>
  .pnl{
    padding: 10px;
  }
  .btn-dl{
    margin-top: 20px;
    margin-bottom: 20px;
  }

  .time{
    color: #99a2aa;
  }
  .name{
    color: #337ab7;
  }
  .btn-sub{
    position: relative;
    left: 40%;
  }
</style>
