import Vue from 'vue'
import Router from 'vue-router'
import login from '@/components/login'
import common from '@/components/common'
import major from '@/components/major'
import fileDetail from '@/components/fileDetail'
import noticeDetail from '@/components/noticeDetail'
import VueCookies from 'vue-cookies'

Vue.use(VueCookies)
Vue.use(Router)

const router = new Router({
  routes: [
    {
      path: '/login',
      name: 'login',
      component: login,
      meta: {noBar: true}
    },
    {
      path: '/',
      name: 'index',
      redirect: { name: 'common' },
      meta: { requiresAuth: true }
    },
    {
      path: '/common',
      name: 'common',
      component: common,
      meta: { requiresAuth: true }
    },
    {
      path: '/major',
      name: 'major',
      component: major,
      meta: { requiresAuth: true }
    },
    {
      path: '/file-detail',
      name: 'fileDetail',
      component: fileDetail,
      meta: { requiresAuth: true }
    },
    {
      path: '/notice-detail',
      name: 'noticeDetail',
      component: noticeDetail,
      meta: { requiresAuth: true }
    }
  ]
})

router.beforeEach((to, from, next) => {
  const token = window.$cookies.get('user')
  if (to.meta.requiresAuth) {
    if (token) {
      next()
    } else {
      next({
        path: '/login',
        query: {redirect: to.fullPath}
      })
    }
  } else {
    next()
  }
})

export default router
