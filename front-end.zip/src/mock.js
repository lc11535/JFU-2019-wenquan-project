// import {getUrlValue} from './utils'
// const Mock = require('mockjs')
// const Random = Mock.Random
// Mock.mock('/api/login', 'post', (opt) => {
//   const username = getUrlValue(opt.body, 'username')
//   // console.log(opt)
//   return {
//     Status: 200,
//     Alias: username,
//     School: '安徽大学',
//     Academy: '计算机科学与技术学院',
//     Major: '计算机科学与技术',
//     Grade: '2017',
//     Auth: 2,
//     SessionID: Random.string(15)
//   }
// })
//
// Mock.mock(RegExp('api/school-list.*'), 'get', (opt) => {
//   return {
//     Status: 200,
//     Data: ['安徽大学', '合肥工业大学']
//   }
// })
//
// Mock.mock(RegExp('/api/notification.*'), 'get', (opt) => {
//   return {
//     Status: 200,
//     Data: [
//       {
//         Title: 'hello',
//         Content: 'hello world',
//         UploadTime: '2019-05-20'
//       },
//       {
//         Title: '停水通知',
//         Content: '停水通知内容',
//         UploadTime: '2019-05-21'
//       }
//     ]
//   }
// })
//
// Mock.mock(RegExp('api/exact-file-list.*'), 'post', (opt) => {
//   const type = decodeURIComponent(getUrlValue(opt.body, 'academy'))
//   if (type === 'general') {
//     const school = decodeURIComponent(getUrlValue(opt.body, 'school'))
//     // alert(school)
//     if (school === '安徽大学') {
//       return {
//         Status: 200,
//         Data: [
//           {
//             name: '概率论',
//             disc: '概率论期末试卷',
//             time: '2019-05-21',
//             id: Random.string(10)
//           }
//         ]
//       }
//     } else {
//       return {
//         Status: 200,
//         Data: [
//           {
//             name: '高等数学',
//             disc: '高等数学期末试卷',
//             time: '2019-05-20',
//             id: Random.string(10)
//           }
//         ]
//       }
//     }
//   } else {
//     const page = parseInt(getUrlValue(opt.body, 'page'))
//     // if (1 === 1) {
//     return {
//       Status: 200,
//       Data: [
//         {
//           'Filename': '安徽大学-数学科学学院-信息与计算科学-幻读是什么幻读有什么问题.pdf',
//           'School': '安徽大学',
//           'Academy': '数学科学学院',
//           'Major': '信息与计算科学',
//           'Course': '数据库',
//           'Uploader': '',
//           'UploadTime': '2019/5/21',
//           'Pointer': '',
//           'Auth': 0,
//           'Description': 'mysql的幻读问题',
//           'Size': 878888,
//           'DownloadTime': 2
//         }
//       ],
//       page: page,
//       page_num: 1
//     }
//     // }
//     // else {
//     //   return {
//     //     Status: 200,
//     //     files: [
//     //       {
//     //         name: '往年试卷',
//     //         course: '高等数学',
//     //         disc: '不错的资源',
//     //         time: '2019-05-21',
//     //         count: 5,
//     //         uploader: 'ssz',
//     //         type: 'pdf'
//     //       }
//     //     ],
//     //     page: page,
//     //     page_num: 10
//     //   }
//     // }
//   }
// })
//
// Mock.mock(RegExp('api/academy-major.*'), 'get', (opt) => {
//   return {
//     Status: 200,
//     Data: {
//       '计算机科学与技术学院': ['计算机科学与技术', '信息安全'],
//       '新闻传播学院': ['广播电视学']
//     }
//   }
// })
//
// Mock.mock(RegExp('api/comment-set.*'), 'get', (opt) => {
//   return {
//     'Status': 200,
//     'Data': [
//       {
//         'Content': '好书好书！',
//         'CommentTime': '2019/5/21',
//         'Commentator': 'ylink'
//       }
//     ]
//   }
// })
//
// Mock.mock(RegExp('api/upload.*'), 'post', (opt) => {
//   console.log(opt)
//   return 0
// })
