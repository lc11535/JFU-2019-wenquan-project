<template>
  <div id="app" >
    <!--<img src="./assets/logo.png">-->
    <div v-if="!$route.meta.noBar">
      <keep-alive>
        <nav-bar></nav-bar>
      </keep-alive>
        <router-view></router-view>
  </div>
    <router-view v-if="$route.meta.noBar"></router-view>
  </div>
</template>

<script>
import nav from './components/navBar'
export default {
  name: 'App',
  components: {
    navBar: nav
  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  height: 100%;
}

</style>
